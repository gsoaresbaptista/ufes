module Dados.Metricas 
    ( media
    , desvioPadrao
    , distancia
    , acuracia
    , matrizConfusao
    ) where

import Utils.Lista

{-|
Dado uma matriz de tamanho L * R^n, matriz de L linhas
pertencente a R^n, calcula a media de cada coluna, retornando
um vetor do espaco R^n.

Entrada:
    * dados: [[Double]] -> Matriz de Double que se deseja
    calcular a media das colunas.
Saida:
    * [Double] -> Vetor contendo as medias de cada coluna.
-}
-- mediaCoordenadas :: [[Double]] -> [Double]
-- mediaCoordenadas dados = 
--     let n = fromIntegral $ length dados
--     in  map (/ n) $ foldl1 (zipWith (+)) dados
media :: [Double] -> Double
media dados =
    let n = fromIntegral $ length dados
    in  (/ n) $ sum dados

{-|
Calcula o desvio padrao para cada coluna da matriz de
tamanho L * R^n, onde L e o numero de linhas e R^n o espaco
dimensional da matriz(numero de colunas), retornando um
vetor do espaco R^n, onde cada elemento da coluna e o desvio
padrao para todas as colunas na mesma aposicao da matriz original.

Entrada:
    * dados: [[Double]] -> Matriz de Double que se deseja
    calcular o desvio padrao das colunas.
Saida:
    * [Double] -> Vetor contendo os desvios-padroes de cada
    coluna.
-}
-- desvioPadrao :: [[Double]] -> [Double]
-- desvioPadrao dados = 
    -- let mediaDados = mediaCoordenadas dados
        -- Faz a diferenca ao quadrado para cada dado
        -- quadradoDiferenca x = map (^2) $ zipWith (-) x mediaDados
        -- diferencas = map quadradoDiferenca dados
        -- n = fromIntegral $ length dados
    -- Soma todas as diferencas, divide pelo tamanho e calcula a 
    -- raiz de cada valor
    -- in [(sqrt . (/ n)) x | x <- foldl1 (zipWith (+)) diferencas]

desvioPadrao :: [Double] -> Double
desvioPadrao dados = 
    let mediaDados = media dados
        -- Faz a diferenca ao quadrado para cada dado
        quadradoDiferenca x = map ((^2) . flip (-) mediaDados) x
        n = fromIntegral $ length dados
    -- Soma todas as diferencas, divide pelo tamanho e calcula
    -- a raiz
    in sqrt . (/ n) . sum $ quadradoDiferenca dados

{-|
Calcula a distância euclidiana entre dois pontos, onde ambos os 
pontos têm suas coordenadas representadas por vetores do R^n.

Entrada:
    * a: [Double] -> Vetor do R^n.
    * b: [Double] -> Vetor do R^n.
Saida:
    * Double -> Número representando a distância euclidiana
    entre os pontos a e b.
-}
distancia :: [Double] -> [Double] -> Double
distancia a b = sqrt . sum $ map (^2) (zipWith (-) a b)

{-|
Calcula acuracia dos dados de entrada comparando os dois
vetores de entrada, em suma, retorna a quantidade de
acertos dividido pelo total.
Entrada:
   * xs: [String] -> Primeiro conjunto de classes.
   * ys: [String] -> Segundo conjunto de classes.
Saida:
   * Double -> Acuracia dos dados xs e ys.
-}
acuracia :: [String] -> [String] -> Double
acuracia _ [] = 0.0
acuracia xs ys = foldl comparar 0 (zip xs ys) / nElementos
    where
        nElementos = fromIntegral . length $ ys
        comparar acc x = if uncurry (==) x then succ acc else acc

contarClasses :: [(String, String)] -> [String] -> String -> [Int]
contarClasses xs classes classe = 
    let dados = filter ((==) classe . fst) xs
        pos l = encontrar (snd l) classes
        incrementar x l = incrementarIndice (pos l) x
    in  foldl incrementar (zeros $ length classes) dados

matrizConfusao :: [String] -> [String] -> [String] -> [[Int]]
matrizConfusao verdadeiros preditos classes =
    let pareados = zip verdadeiros preditos
        pegarLinha c xs = contarClasses pareados classes c:xs
    in  transpor $ foldr pegarLinha [] classes